<?php
/*
 * @version $Id: slalevel_ticket.class.php 20130 2013-02-04 16:55:15Z moyo $
 -------------------------------------------------------------------------
 GLPI - Gestionnaire Libre de Parc Informatique
 Copyright (C) 2003-2013 by the INDEPNET Development Team.

 http://indepnet.net/   http://glpi-project.org
 -------------------------------------------------------------------------

 LICENSE

 This file is part of GLPI.

 GLPI is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 GLPI is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with GLPI. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

// ----------------------------------------------------------------------
// Original Author of file: Remi Collet
// Purpose of file:
// ----------------------------------------------------------------------

if (!defined('GLPI_ROOT')) {
   die("Sorry. You can't access directly to this file");
}

/// Class SLA
class SlaLevel_Ticket extends CommonDBTM {


   /**
    * Retrieve an item from the database
    *
    * @param $ID ID of the item to get
    *
    * @return true if succeed else false
   **/
   function getFromDBForTicket ($ID) {
      global $DB;

      // Make new database object and fill variables
      if (empty($ID)) {
         return false;
      }

      $query = "SELECT *
                FROM `".$this->getTable()."`
                WHERE `tickets_id` = '$ID'";

      if ($result = $DB->query($query)) {
         if ($DB->numrows($result)>0) {
            $this->fields = $DB->fetch_assoc($result);
            return true;
         }
      }
      return false;
   }


   /**
    * Delete entries for a ticket
    *
    * @param $tickets_id Ticket ID
    *
    * @return nothing
   **/
   static function deleteForTicket ($tickets_id) {
      global $DB;

      $query1 = "DELETE
                 FROM `glpi_slalevels_tickets`
                 WHERE `tickets_id` = '$tickets_id'";
      $DB->query($query1);
   }


   /**
    * Give cron informations
    *
    * @param $name : task's name
    *
    * @return arrray of informations
   **/
   static function cronInfo($name) {
      global $LANG;

      switch ($name) {
         case 'slaticket' :
            return array('description' => $LANG['crontask'][16]);
      }
      return array();
   }


   /**
    * Cron for ticket's automatic close
    *
    * @param $task : crontask object
    *
    * @return integer (0 : nothing done - 1 : done)
   **/
   static function cronSlaTicket($task) {
      global $DB;

      $tot = 0;

      $query = "SELECT *
                FROM `glpi_slalevels_tickets`
                WHERE `glpi_slalevels_tickets`.`date` < NOW()";

      foreach ($DB->request($query) as $data) {
         $tot++;
         self::doLevelForTicket($data);
      }

      $task->setVolume($tot);
      return ($tot > 0);
   }


   /**
    * Do a specific SLAlevel for a ticket
    *
    * @param $data array data of a entry of slalevels_tickets
    *
    * @return nothing
   **/
   static function doLevelForTicket($data) {

      $ticket         = new Ticket();
      $slalevelticket = new self();

      if ($ticket->getFromDB($data['tickets_id'])) {
         $slalevel = new SlaLevel();
         $sla      = new SLA();
         // Check if sla datas are OK
         if ($ticket->fields['slas_id'] > 0
             && $ticket->fields['slalevels_id'] == $data['slalevels_id']) {

            if ($ticket->fields['status'] == 'closed') {
               // Drop line when status is closed
               $slalevelticket->delete(array('id' => $data['id']));

            } else if ($ticket->fields['status'] != 'solved') {
               // If status = solved : keep the line in case of solution not validated
               $input['id'] = $ticket->getID();
               $input['_auto_update'] = true;

               if ($slalevel->getRuleWithCriteriasAndActions($data['slalevels_id'],0,1)
                   && $sla->getFromDB($ticket->fields['slas_id'])) {
                  // Process rules
                  $input = $slalevel->executeActions($input,array());
               }

               // Put next level in todo list
               $next = $slalevel->getNextSlaLevel($ticket->fields['slas_id'],
                                                  $ticket->fields['slalevels_id']);
               $input['slalevels_id'] = $next;
               $ticket->update($input);
               $sla->addLevelToDo($ticket);
               // Action done : drop the line
               $slalevelticket->delete(array('id' => $data['id']));
            }
         } else {
            // Drop line
            $slalevelticket->delete(array('id' => $data['id']));
         }

      } else {
         // Drop line
         $slalevelticket->delete(array('id' => $data['id']));
      }
   }


   /**
    * Replay all task needed for a specific ticket
    *
    * @param $tickets_id Ticket ID
    *
    * @return nothing
   **/
   static function replayForTicket($tickets_id) {
      global $DB;

      $query = "SELECT *
                FROM `glpi_slalevels_tickets`
                WHERE `glpi_slalevels_tickets`.`date` < NOW()
                      AND `tickets_id` = '$tickets_id'";

      $number = 0;
      do {
         if ($result = $DB->query($query)) {
            $number = $DB->numrows($result);
            if ($number == 1) {
               $data = $DB->fetch_assoc($result);
               self::doLevelForTicket($data);
            }
         }
      } while ($number == 1);
   }

}

?>