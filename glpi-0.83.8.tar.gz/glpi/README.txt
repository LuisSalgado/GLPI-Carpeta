See the Installation Guide found on GLPI-PROJECT.ORG for installation steps of GLPI.
 
http://www.glpi-project.org/README
